# CarePoint Hospital website

Plain HTML, CSS and JavaScript. No build step. Open `index.html` in a browser, or upload the whole folder to any host (cPanel, Netlify, Vercel, GitHub Pages).

## Folder map

- `index.html` plus 16 more pages in the root (about, services, service, doctors, doctor, appointments, emergency, patients, portal, billing, locations, contact, careers, news, privacy, terms)
- `css/style.css` all styling. Colours and sizes are variables at the top.
- `js/data.js` **all content lives here**: phone, address, hours, services, doctors, health articles, job roles.
- `js/layout.js` shared header, footer, mobile menu, image fallbacks.
- `js/main.js` search filters, doctor and service pages, forms, tabs.
- `images/` put your photos here (see list below).

## Images still needed

Gamma could not make images (free plan, out of credits), so every image slot shows a clean labelled placeholder. Add JPG files to `images/` with these exact names and they appear automatically:

`hero.jpg`, `about.jpg`, `reception.jpg`, `nurse.jpg`, `lab.jpg`, `imaging.jpg`, `pharmacy.jpg`, `therapy.jpg`, `emergency.jpg`, `doctor-1.jpg`, `doctor-2.jpg`, `doctor-3.jpg`, `doctor-4.jpg`, `team.jpg`, `waiting.jpg`, `lifestyle.jpg`

Wide images: about 1600x900. Doctor portraits: 800x1000.

## Things CarePoint must confirm before launch

Search the files for `TODO` and "to be confirmed".

1. Real email address (`js/data.js`, `CP.email`).
2. Opening hours (`CP.hours`).
3. Real departments and services (`SERVICES`). Only offer what CarePoint really provides.
4. Real doctors, photos and credentials (`DOCTORS`). The six listed are **sample profiles**. Set `showSampleBadge: false` once real.
5. Whether emergency or urgent care is offered, and when.
6. Accepted insurance plans (`billing.html`).
7. Sample job roles (`CAREERS`), visiting hours, parking details.
8. Privacy Policy and Terms are templates. Get a lawyer to review them.

## Forms and the portal

- The appointment and contact forms validate input and show a confirmation, but **nothing is emailed or stored on a server**. Requests are only saved in the visitor's own browser (`localStorage`). Connect them to a real service (a form backend, your email, or a booking system) before launch.
- Patient data can be sensitive. Use a provider that supports US health privacy rules (HIPAA) for anything that collects health information.
- The Patient Portal page is a design preview. Link the login and register forms to your real portal provider.

## Design notes

Deep blue primary `#0B4F6C`, teal accents, coral highlights, Poppins headings and Inter body text. Buttons use a darker teal (`#007C7C`) so white text stays readable. Mobile first, 48px touch targets, visible focus rings, reduced-motion support and a sticky Call / WhatsApp / Book bar on phones.
