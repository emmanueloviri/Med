Put CarePoint photos in this folder with these exact file names.
Until a file exists, the site shows a clean labelled placeholder in its place.

hero.jpg        Home hero: hospital exterior or doctor and patient (4:3)
about.jpg       Hospital building or doctor consulting a patient (4:3)
reception.jpg   Welcoming reception desk (4:3)
nurse.jpg       Caring nurse with a patient (4:3)
lab.jpg         Laboratory (4:3)
imaging.jpg     Diagnostic imaging room (4:3)
pharmacy.jpg    Pharmacy (4:3)
therapy.jpg     Physical therapy session (4:3)
emergency.jpg   Emergency entrance / ambulance bay (4:3)
doctor-1.jpg    Doctor headshot (portrait, 4:5)
doctor-2.jpg    Doctor headshot (portrait, 4:5)
doctor-3.jpg    Doctor headshot (portrait, 4:5)
doctor-4.jpg    Doctor headshot (portrait, 4:5)
team.jpg        Staff group photo (4:3)
waiting.jpg     Waiting area (4:3)
lifestyle.jpg   Healthy lifestyle / Key West community (16:9)

Use real photos of the CarePoint team and building where possible.
Compress images (under about 300 KB each) so pages load fast.
