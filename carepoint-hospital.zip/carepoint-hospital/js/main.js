/* CarePoint Hospital - page behaviour. Each page sets <body data-page="..."> */
(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const params = new URLSearchParams(location.search);
  const svc = (id) => SERVICES.find((s) => s.id === id);
  const sampleBadge = () => (CP.showSampleBadge ? '<span class="badge sample">Sample profile</span>' : '');

  /* ---------- Reusable renderers ---------- */
  function serviceCard(s) {
    return `<a class="card reveal" href="service.html?id=${s.id}">
      <div class="card-icon">${icon(s.icon)}</div>
      <h3>${s.name}</h3><p>${s.short}</p>
      <span class="more">Learn more ${icon('arrow')}</span></a>`;
  }
  function doctorCard(d) {
    return `<article class="card doctor-card reveal">
      <div class="media portrait">${img(d.img, d.name + ', ' + d.spec)}</div>
      <div class="body">
        <h3>${d.name}</h3><span class="spec">${d.spec}</span>
        <span class="badge">${icon('check')} Accepting new patients</span>
        ${sampleBadge()}
        <div class="actions">
          <a class="btn btn-outline btn-sm" href="doctor.html?id=${d.id}">View Profile</a>
          <a class="btn btn-primary btn-sm" href="appointments.html?doctor=${d.id}">Book</a>
        </div>
      </div></article>`;
  }
  function articleCard(a) {
    return `<article class="card article-card reveal">
      <div class="media wide" style="margin-bottom:16px">${img(a.img, a.title)}</div>
      <span class="badge">${a.tag}</span>
      <h3 style="margin-top:10px">${a.title}</h3>
      <p class="meta">${a.date}</p>
      <details class="faq" style="margin-top:12px"><summary>Read article</summary>
        <div class="answer">${a.body.map((p) => '<p>' + p + '</p>').join('')}
        <p class="meta">General information only. It is not a substitute for professional medical advice.</p></div></details>
    </article>`;
  }

  /* ---------- Form helpers ---------- */
  function fieldOf(el) { return el.closest('.field'); }
  function checkField(el) {
    const f = fieldOf(el); if (!f) return true;
    const msg = $('.error-msg', f);
    let ok = true, text = '';
    const v = (el.value || '').trim();
    if (el.type === 'checkbox') { if (el.required && !el.checked) { ok = false; text = 'Please tick this box to continue.'; } }
    else if (el.type === 'radio') { return true; }
    else if (el.required && !v) { ok = false; text = 'This field is required.'; }
    else if (v && el.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) { ok = false; text = 'Enter a valid email, like name@example.com.'; }
    else if (v && el.type === 'tel' && v.replace(/\D/g, '').length < 7) { ok = false; text = 'Enter a phone number with at least 7 digits.'; }
    else if (v && el.type === 'date' && el.dataset.max === 'today' && v > new Date().toISOString().slice(0, 10)) { ok = false; text = 'Date cannot be in the future.'; }
    else if (v && el.type === 'date' && el.min && v < el.min) { ok = false; text = 'Choose today or a later date.'; }
    f.classList.toggle('invalid', !ok);
    if (msg) msg.textContent = text;
    el.setAttribute('aria-invalid', String(!ok));
    return ok;
  }
  function wireValidation(form) {
    $$('input, select, textarea', form).forEach((el) => {
      el.addEventListener('blur', () => checkField(el));
      el.addEventListener('input', () => { if (fieldOf(el) && fieldOf(el).classList.contains('invalid')) checkField(el); });
      el.addEventListener('change', () => { if (fieldOf(el) && fieldOf(el).classList.contains('invalid')) checkField(el); });
    });
  }
  function validateAll(form) {
    let first = null;
    $$('input, select, textarea', form).forEach((el) => { if (!checkField(el) && !first) first = el; });
    if (first) first.focus();
    return !first;
  }
  function saveLocal(key, record) {
    try {
      const list = JSON.parse(localStorage.getItem(key) || '[]'); list.push(record);
      localStorage.setItem(key, JSON.stringify(list));
    } catch (e) { /* storage may be blocked: the form still works */ }
  }
  const refNo = () => 'CP-' + Date.now().toString(36).toUpperCase().slice(-6);
  function showSuccess(form, panel, ref) {
    form.hidden = true; panel.classList.add('show');
    const r = $('.ref', panel); if (r) r.textContent = ref;
    panel.setAttribute('tabindex', '-1'); panel.focus();
    panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- Pages ---------- */
  const pages = {
    home() {
      $('#featured-services').innerHTML = ['primary-care', 'cardiology', 'paediatrics', 'laboratory', 'imaging', 'pharmacy'].map((id) => serviceCard(svc(id))).join('');
      $('#featured-doctors').innerHTML = DOCTORS.slice(0, 4).map(doctorCard).join('');
      $('#featured-news').innerHTML = ARTICLES.slice(0, 3).map(articleCard).join('');
    },

    services() {
      const grid = $('#service-grid'), count = $('#service-count'), q = $('#service-search');
      let cat = 'all';
      const draw = () => {
        const term = q.value.trim().toLowerCase();
        const list = SERVICES.filter((s) => (cat === 'all' || s.cat === cat) && (!term || (s.name + ' ' + s.short + ' ' + s.conditions.join(' ')).toLowerCase().includes(term)));
        count.textContent = list.length + (list.length === 1 ? ' service found' : ' services found');
        grid.innerHTML = list.length ? list.map(serviceCard).join('') : '<div class="empty" style="grid-column:1/-1">No services match your search. Try a different word or call us on ' + CP.phone + '.</div>';
        revealInit();
      };
      q.addEventListener('input', draw);
      $$('.tab').forEach((t) => t.addEventListener('click', () => {
        $$('.tab').forEach((x) => x.setAttribute('aria-selected', 'false'));
        t.setAttribute('aria-selected', 'true'); cat = t.dataset.cat; draw();
      }));
      draw();
    },

    service() {
      const s = svc(params.get('id'));
      const box = $('#service-detail');
      if (!s) { box.innerHTML = '<div class="empty">That service was not found. <a href="services.html">Browse all services</a>.</div>'; return; }
      document.title = s.name + ' | CarePoint Hospital';
      const docs = DOCTORS.filter((d) => d.service === s.id);
      box.innerHTML = `
        <div class="breadcrumb"><a href="index.html">Home</a> / <a href="services.html">Services</a> / ${s.name}</div>
        <div class="split">
          <div><span class="eyebrow">Our services</span><h1>${s.name}</h1><p class="lead">${s.overview}</p>
            <div style="display:flex;gap:12px;flex-wrap:wrap"><a class="btn btn-primary" href="appointments.html?service=${s.id}">${icon('calendar')} Book Appointment</a><a class="btn btn-outline" href="tel:${CP.tel}">${icon('phone')} ${CP.phone}</a></div></div>
          <div class="media">${img(s.img, s.name + ' at CarePoint', 'loading="eager"')}</div>
        </div>
        <div class="grid grid-2" style="margin-top:48px">
          <div class="card"><h3>Conditions we treat</h3><ul class="check-list">${s.conditions.map((c) => '<li>' + icon('check') + '<span>' + c + '</span></li>').join('')}</ul></div>
          <div class="card"><h3>Procedures and care</h3><ul class="check-list">${s.procedures.map((c) => '<li>' + icon('check') + '<span>' + c + '</span></li>').join('')}</ul></div>
        </div>
        <h2 style="margin-top:56px">${docs.length ? 'Doctors in ' + s.name : 'Ready to see someone?'}</h2>
        ${docs.length ? '<div class="grid grid-3">' + docs.map(doctorCard).join('') + '</div>' : '<p>Call us or send a request and our team will match you with the right clinician.</p>'}`;
      revealInit();
    },

    doctors() {
      const grid = $('#doctor-grid'), count = $('#doctor-count'), q = $('#doctor-search'), sel = $('#doctor-spec');
      [...new Set(DOCTORS.map((d) => d.spec))].sort().forEach((sp) => sel.insertAdjacentHTML('beforeend', '<option>' + sp + '</option>'));
      const draw = () => {
        const term = q.value.trim().toLowerCase();
        const list = DOCTORS.filter((d) => (!sel.value || d.spec === sel.value) && (!term || (d.name + ' ' + d.spec).toLowerCase().includes(term)));
        count.textContent = list.length + (list.length === 1 ? ' doctor found' : ' doctors found');
        grid.innerHTML = list.length ? list.map(doctorCard).join('') : '<div class="empty" style="grid-column:1/-1">No doctors match your search. Clear a filter or call ' + CP.phone + ' and we will help.</div>';
        revealInit();
      };
      q.addEventListener('input', draw); sel.addEventListener('change', draw); draw();
    },

    doctor() {
      const d = DOCTORS.find((x) => x.id === params.get('id'));
      const box = $('#doctor-profile');
      if (!d) { box.innerHTML = '<div class="empty">That doctor was not found. <a href="doctors.html">See all doctors</a>.</div>'; return; }
      document.title = d.name + ' | CarePoint Hospital';
      const s = svc(d.service);
      box.innerHTML = `
        <div class="breadcrumb"><a href="index.html">Home</a> / <a href="doctors.html">Find a Doctor</a> / ${d.name}</div>
        <div class="profile">
          <div><div class="media portrait">${img(d.img, d.name + ', ' + d.spec, 'loading="eager"')}</div></div>
          <div>
            <h1>${d.name}</h1>
            <p class="lead" style="margin-bottom:10px">${d.spec}${s ? ' &middot; <a href="service.html?id=' + s.id + '">' + s.name + ' department</a>' : ''}</p>
            <div style="display:flex;gap:8px;flex-wrap:wrap"><span class="badge">${icon('check')} Accepting new patients</span>${sampleBadge()}</div>
            <p style="margin-top:20px">${d.bio}</p>
            <div class="facts">
              <div class="fact"><strong>Education</strong>${d.education}</div>
              <div class="fact"><strong>Residency / training</strong>${d.residency}</div>
              <div class="fact"><strong>Board certification</strong>${d.board}</div>
              <div class="fact"><strong>Clinical interests</strong>${d.interests}</div>
              <div class="fact"><strong>Clinic days</strong>${d.days}</div>
              <div class="fact"><strong>Languages</strong>English</div>
            </div>
            <a class="btn btn-primary" href="appointments.html?doctor=${d.id}">${icon('calendar')} Book with ${d.name.split(' ').slice(0, 2).join(' ')}</a>
          </div>
        </div>`;
    },

    appointments() {
      const form = $('#appt-form'), service = $('#f-service'), doctor = $('#f-doctor'), date = $('#f-date');
      service.innerHTML = '<option value="">Select a department or service</option>' + SERVICES.map((s) => `<option value="${s.id}">${s.name}</option>`).join('');
      const fillDoctors = () => {
        const list = DOCTORS.filter((d) => !service.value || d.service === service.value);
        doctor.innerHTML = '<option value="">No preference</option>' + list.map((d) => `<option value="${d.id}">${d.name} (${d.spec})</option>`).join('');
      };
      date.min = new Date().toISOString().slice(0, 10);
      fillDoctors();
      const d0 = DOCTORS.find((d) => d.id === params.get('doctor'));
      if (d0) { service.value = d0.service; fillDoctors(); doctor.value = d0.id; }
      else if (svc(params.get('service'))) { service.value = params.get('service'); fillDoctors(); }
      service.addEventListener('change', fillDoctors);
      wireValidation(form);
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!validateAll(form)) return;
        const data = Object.fromEntries(new FormData(form).entries());
        const ref = refNo();
        saveLocal('cp_appointment_requests', Object.assign({ ref, created: new Date().toISOString() }, data));
        $('#success-name').textContent = data.name.split(' ')[0];
        showSuccess(form, $('#appt-success'), ref);
      });
    },

    contact() {
      const form = $('#contact-form');
      wireValidation(form);
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!validateAll(form)) return;
        const data = Object.fromEntries(new FormData(form).entries());
        const ref = refNo();
        saveLocal('cp_messages', Object.assign({ ref, created: new Date().toISOString() }, data));
        showSuccess(form, $('#contact-success'), ref);
      });
    },

    news() {
      const wrap = $('#news-grid');
      wrap.innerHTML = ARTICLES.map(articleCard).join('');
      revealInit();
    },

    careers() {
      $('#roles').innerHTML = CAREERS.map((r) => `
        <div class="card reveal" style="display:flex;gap:16px;justify-content:space-between;align-items:center;flex-wrap:wrap">
          <div><h3 style="margin:0">${r.title}</h3><p class="meta" style="margin:4px 0 0">${r.dept} &middot; ${r.type} &middot; ${CP.address.city}, ${CP.address.state}</p></div>
          <a class="btn btn-outline btn-sm" href="mailto:${CP.email}?subject=${encodeURIComponent('Application: ' + r.title)}">Apply by email</a>
        </div>`).join('');
      revealInit();
    },

    portal() {
      const tabs = $$('.tab'), panels = $$('.tab-panel');
      const show = (id) => {
        tabs.forEach((t) => t.setAttribute('aria-selected', String(t.dataset.tab === id)));
        panels.forEach((p) => { p.hidden = p.id !== 'panel-' + id; });
      };
      tabs.forEach((t) => t.addEventListener('click', () => show(t.dataset.tab)));
      if (location.hash === '#register') show('register'); else if (location.hash === '#help') show('help');
      ['login-form', 'register-form'].forEach((id) => {
        const f = document.getElementById(id); wireValidation(f);
        f.addEventListener('submit', (e) => {
          e.preventDefault();
          if (!validateAll(f)) return;
          $('.demo-result', f).hidden = false;
        });
      });
    }
  };

  /* ---------- Scroll reveal ---------- */
  let observer;
  function revealInit() {
    const els = $$('.reveal:not(.in)');
    if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) { els.forEach((e) => e.classList.add('in')); return; }
    observer = observer || new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add('in'); observer.unobserve(en.target); } });
    }, { threshold: 0.12 });
    els.forEach((e) => observer.observe(e));
  }

  const key = document.body.dataset.page;
  if (pages[key]) pages[key]();
  revealInit();
})();
