/* Shared header, footer, mobile action bar and image fallbacks. */
(function () {
  document.documentElement.classList.add('js');

  const NAV = [
    ['services.html', 'Services'],
    ['doctors.html', 'Find a Doctor'],
    ['patients.html', 'Patients & Visitors'],
    ['billing.html', 'Billing & Insurance'],
    ['about.html', 'About'],
    ['contact.html', 'Contact']
  ];
  const page = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  const related = { 'service.html': 'services.html', 'doctor.html': 'doctors.html', 'locations.html': 'contact.html', 'portal.html': 'patients.html' };
  const current = related[page] || page;

  const navLinks = (cls) => NAV.map(([href, label]) =>
    `<a href="${href}"${href === current ? ' aria-current="page"' : ''}>${label}</a>`).join('');

  const header = `
  <a class="skip-link" href="#main">Skip to main content</a>
  <div class="topbar"><div class="container">
    <span>Life-threatening emergency? Call <strong>911</strong> now.</span>
    <a href="tel:${CP.tel}">${icon('phone')} ${CP.phone}</a>
  </div></div>
  <header class="site-header">
    <div class="container nav-wrap">
      <a class="logo" href="index.html" aria-label="${CP.name} home">
        <span class="logo-mark"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z"/></svg></span>
        <span>CarePoint<small>Hospital</small></span>
      </a>
      <nav class="nav" aria-label="Main">
        <ul>${NAV.map(([href, label]) => `<li><a href="${href}"${href === current ? ' aria-current="page"' : ''}>${label}</a></li>`).join('')}</ul>
      </nav>
      <div class="header-actions">
        <a class="btn btn-outline btn-sm" href="portal.html">Patient Portal</a>
        <a class="btn btn-primary btn-sm" href="appointments.html">Book Appointment</a>
      </div>
      <button class="menu-btn" id="menuBtn" aria-expanded="false" aria-controls="mobileNav" aria-label="Open menu">${icon('menu')}</button>
    </div>
    <nav class="mobile-nav" id="mobileNav" aria-label="Mobile">
      <div class="container">
        ${navLinks()}
        <a href="emergency.html"${current === 'emergency.html' ? ' aria-current="page"' : ''}>Emergency &amp; Urgent Care</a>
        <a class="btn btn-primary" href="appointments.html">Book Appointment</a>
        <a class="btn btn-outline" href="portal.html">Patient Portal</a>
      </div>
    </nav>
  </header>`;

  const footer = `
  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div>
          <a class="logo" href="index.html"><span class="logo-mark"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z"/></svg></span><span>CarePoint<small>Hospital</small></span></a>
          <p>Compassionate, high-quality care for individuals and families in the Florida Keys.</p>
        </div>
        <div>
          <h3>Contact</h3>
          <div class="contact-line">${icon('pin')}<span>${CP.address.street}<br>${CP.address.city}, ${CP.address.state} ${CP.address.zip}</span></div>
          <div class="contact-line">${icon('phone')}<a href="tel:${CP.tel}">${CP.phone}</a></div>
          <div class="contact-line">${icon('mail')}<a href="mailto:${CP.email}">${CP.email}</a></div>
        </div>
        <div>
          <h3>Patients</h3>
          <ul>
            <li><a href="appointments.html">Request an Appointment</a></li>
            <li><a href="doctors.html">Find a Doctor</a></li>
            <li><a href="portal.html">Patient Portal</a></li>
            <li><a href="billing.html">Billing &amp; Insurance</a></li>
            <li><a href="patients.html">Visitors &amp; FAQs</a></li>
          </ul>
        </div>
        <div>
          <h3>CarePoint</h3>
          <ul>
            <li><a href="about.html">About Us</a></li>
            <li><a href="services.html">Our Services</a></li>
            <li><a href="locations.html">Locations &amp; Directions</a></li>
            <li><a href="careers.html">Careers</a></li>
            <li><a href="news.html">News &amp; Health Tips</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-emergency"><strong>In a life-threatening emergency, call 911 immediately.</strong> This website does not provide emergency services or medical advice.</div>
      <div class="footer-bottom">
        <span>&copy; ${new Date().getFullYear()} ${CP.name}. All rights reserved.</span>
        <span><a href="privacy.html">Privacy Policy</a> &nbsp;|&nbsp; <a href="terms.html">Terms of Use</a></span>
      </div>
    </div>
  </footer>
  <nav class="action-bar" aria-label="Quick actions">
    <a href="tel:${CP.tel}">${icon('phone')}Call</a>
    <a href="${CP.whatsapp}" target="_blank" rel="noopener">${icon('message')}WhatsApp</a>
    <a class="book" href="appointments.html">${icon('calendar')}Book</a>
  </nav>`;

  document.getElementById('site-header').innerHTML = header;
  document.getElementById('site-footer').innerHTML = footer;

  const btn = document.getElementById('menuBtn');
  const mnav = document.getElementById('mobileNav');
  btn.addEventListener('click', () => {
    const open = mnav.classList.toggle('open');
    btn.setAttribute('aria-expanded', open);
    btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    btn.innerHTML = icon(open ? 'x' : 'menu');
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mnav.classList.contains('open')) { btn.click(); btn.focus(); }
  });

  /* Image slots: if a file is missing, show a clean labelled placeholder instead of a broken image. */
  window.cpImgFallback = function (img) {
    const label = img.getAttribute('alt') || 'Image';
    const box = document.createElement('div');
    box.className = 'img-fallback';
    box.setAttribute('role', 'img');
    box.setAttribute('aria-label', label);
    box.innerHTML = icon('image') + '<span>' + label + '</span>';
    img.replaceWith(box);
  };
  document.addEventListener('error', (e) => {
    if (e.target && e.target.tagName === 'IMG' && e.target.dataset.slot) window.cpImgFallback(e.target);
  }, true);
  document.querySelectorAll('img[data-slot]').forEach((img) => {
    if (img.complete && img.naturalWidth === 0) window.cpImgFallback(img);
  });
})();

/* Icon helpers for static pages: <i data-icon="phone"></i> and <ul class="check-list auto"> */
(function () {
  document.querySelectorAll('i[data-icon]').forEach((el) => {
    const t = document.createElement('span');
    t.style.display = 'inline-flex';
    t.innerHTML = icon(el.dataset.icon);
    el.replaceWith(t.firstChild);
  });
  document.querySelectorAll('ul.check-list.auto > li').forEach((li) => li.insertAdjacentHTML('afterbegin', icon('check')));
})();

function img(file, alt, extra) {
  return '<img src="images/' + file + '" alt="' + alt + '" data-slot="1" loading="lazy" ' + (extra || '') + '>';
}
